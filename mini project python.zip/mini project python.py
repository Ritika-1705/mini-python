Python 3.14.3 (tags/v3.14.3:323c59a, Feb  3 2026, 16:04:56) [MSC v.1944 64 bit (AMD64)] on win32
Enter "help" below or click "Help" above for more information.
>>> # Marks Analyzer Mini Project
... 
... def calculate_grade(avg):
...     if avg >= 90:
...         return 'A+'
...     elif avg >= 75:
...         return 'A'
...     elif avg >= 60:
...         return 'B'
...     elif avg >= 50:
...         return 'C'
...     else:
...         return 'F'
... 
... 
... students = []
... 
... n = int(input("Enter number of students: "))
... 
... for i in range(n):
...     print(f"\nEnter details for Student {i+1}")
...     name = input("Name: ")
...     
...     marks = []
...     for j in range(5):  # 5 subjects
...         m = float(input(f"Enter mark for subject {j+1}: "))
...         marks.append(m)
...     
...     total = sum(marks)
...     avg = total / len(marks)
...     grade = calculate_grade(avg)
...     
...     student = {
...         "name": name,
...         "marks": marks,
...         "total": total,
...         "average": avg,
...         "grade": grade
...     }
...     
...     students.append(student)
... 
... 
... # Analysis
... class_total = 0
topper = students[0]
failed_students = []

for student in students:
    class_total += student["average"]
    
    if student["average"] > topper["average"]:
        topper = student
    
    if student["grade"] == 'F':
        failed_students.append(student["name"])


class_average = class_total / n


# Output
print("\n===== STUDENT REPORT =====")
for s in students:
    print("\nName:", s["name"])
    print("Marks:", s["marks"])
    print("Total:", s["total"])
    print("Average:", round(s["average"], 2))
    print("Grade:", s["grade"])

print("\n===== ANALYSIS =====")
print("Class Average:", round(class_average, 2))
print("Topper:", topper["name"], "-", round(topper["average"], 2))

